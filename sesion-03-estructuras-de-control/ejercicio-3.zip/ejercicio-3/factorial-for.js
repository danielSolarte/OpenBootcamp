// CALCULAR FACTORIAL DE 10

let resultado = 1;

for (i = 1; i <= 10; i++){
    resultado *= i;
}

console.log(resultado);
