// FACTORIAL DE 10 USANDO BUCLE WHILE

let resultado = 1;
let i = 1;

while(i<=10){
    resultado *= i;
    i++;
}

console.log(resultado);